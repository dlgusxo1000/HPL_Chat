import React, { Component } from 'react';
import Container from './components/ScreenContainer';



export default class App extends Component {
  
  constructor() {
    super();
    console.disableYellowBox = true;
    }
    

  render() {
    return (
      <Container />
    );
  }
}
