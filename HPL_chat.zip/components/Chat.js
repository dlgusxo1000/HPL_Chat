import React from 'react';
import {Text,KeyboardAvoidingView} from 'react-native';
import { GiftedChat } from 'react-native-gifted-chat';
import Fire from './Fire';

class Chat extends React.Component{
    static navigationOptions = ({ navigation }) => ({
    title: (navigation.state.params || {}).name || 'Chat!',
  });
    state = {
        messages: [],
    }
    get user(){
        return {
            name: 'HPL',
            _id : Fire.shared.uid,
        }
    }
    render(){
        const mainContent = (
            <GiftedChat
                messages={this.state.messages}
                onSend={Fire.shared.send}
                user={this.user}
            />
        )
        return(
            <KeyboardAvoidingView style={{flex:1}} behavior="padding" keyboardVerticalOffset={-230} enabled>
                {mainContent}
            </KeyboardAvoidingView>
        );
    }
    componentDidMount() {
        Fire.shared.on(message =>
          this.setState(previousState => ({
            messages: GiftedChat.append(previousState.messages, message),
          }))
        );
      }
      componentWillUnmount() {
        Fire.shared.off();
    }
}
export default Chat;