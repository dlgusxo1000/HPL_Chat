import React, { Component } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import Expo from 'expo';
import { TextInput } from 'react-native-gesture-handler';

//var { ivalue } = "";

async function getToken() {
//원격지 알람은 기기에서만 된다.
if(!Expo.Constants.isDevice){
return;
}

let { status } = await Expo.Permissions.askAsync(
Expo.Permissions.NOTIFICATIONS
);

if(status != 'granted'){
console.log("설정에서 알람 활성화 필요");
return;
}

//push 이후에 반환받은 값 담기
let value = await Expo.Notifications.getExpoPushTokenAsync();
console.log('토큰값 ', value);
alert(value);
}

export default class App extends React.Component {

state = {
tokenValue : ""
};

componentDidMount(){
getToken();

this.listener = Expo.Notifications.addListener(this.handleNotification);
}

componentWillUnmount(){
this.listener && this.listener.remove();
}

handleNotification = ({ origin, data }) => {
console.log(
`push notificaton ${origin} with data : ${JSON.stringify(data)}`
);
};


render() {

const { tokenValue } = this.state;

return (
<View style={styles.container}>
<Text style={styles.paragraph}>notification test</Text>
</View>
);
}
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#fff',
alignItems: 'center',
justifyContent: 'center',
},
paragraph : {
margin : 24,
fontSize : 18,
fontWeight : 'bold',
textAlign : 'center',
color : '#34495e'
}
});


출처: https://aspdotnet.tistory.com/2115 [심재운 블로그]